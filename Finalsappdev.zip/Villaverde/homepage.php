<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Homepage</title>
    <style>
        body {
            margin: 0;
            padding-top: 100px;
            background: #0e2242;
        }

        .header {
            padding: 16px;
            background: #163973;
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1; 
        }

        #logo {
            width: 80px;
            height: 50px;
            margin-left: 40px;
            padding: 10px;
        }

        .logo,.pages,.login {
            float: left;
        }

        .logo,.login {
            width: 15%;
        }

        .pages {
            width: 70%;
            margin-top: 25px;
        }

        .header:after {
            content: "";
            display: table;
            clear: both;
        }

        .fest,.season,.leaderboard,.event,.news,.store {
            width: 13.7%;
            float: left;
            padding: 10px;
        }

        .links:after {
            content: "";
            display: table;
            clear: both;
        }

        a:link {
            text-decoration: none;
            color: white;
        }

        a:visited {
            text-decoration: none;
            color: white;
        }

        a:hover {
            text-decoration: underline;
            border: 2px solid;
            border-radius: 5px;
            padding: 5px;
        }

        a:active {
            text-decoration: underline;
        }

        .loginb {
            margin-top: 25px;
            color: white;
            padding: 10px;
        }
        .video-container {
            width: 100%;
            height: 0;
            padding-bottom: 55%;
            position: relative;
        }
        .video-container iframe {
            position: absolute;
            top: 0;
            left: 19px;
            width: 98%;
            height: 90%;
        }
        .pokemon-container {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: row;
        }
        .pokemon-box {
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            width: 30%;
            margin: 2px 50px 80px 50px;
            box-shadow: 10px 10px #163973;
        }
        .pokemon-image {
            padding: 20px;
            width: 200px;
            height: 200px;
            margin-right: 20px;
        }
        .pokemon-description {
            font-size: 15px;
            text-align: center;
        }
        .footer {
            background: #163973;
            color: white;
            padding: 30px;
            text-align: center;
            bottom: 0;
            width: 100%;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        
        .footer a {
            color: white;
            text-decoration: wordwrap;
            margin: 5px;
            font-size: 17px;
        }
        
        .footer div {
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="whole">
        <div class="header">
            <div class="logo">
                <a href="homepage.php"><img id="logo" src="https://lh3.googleusercontent.com/3TSaKxXGo2wT0lu0AyNUBnkk6wkCC2AzOhJyy3JXIPm-AmZ1k9DSAroWeBUyePswCZSs5lVp3mPF7HzUpY9VPlyOV5eddITONINr3WSqLNLm=e365-w512"></a>
            </div>
            <div class="pages">
                <div class="links">
                    <div class="fest">
                        <a href="gofest.php" id="gfest">
                            GO FEST
                        </a>
                    </div>
                    <div class="season">
                        <a href="season.php" id="sea">
                            SEASON
                        </a>
                    </div>
                    <div class="leaderboard">
                        <a href="leaderboard.php" id="leaderbords">
                            LEADERBOARDS
                        </a>
                    </div>
                    <div class="event">
                        <a href="event.php" id="events">
                            EVENTS
                        </a>
                    </div>
                    <div class="news">
                        <a href="news.php" id="new">
                            NEWS
                        </a>
                    </div>
                    <div class="store">
                        <a href="store.php" id="store">
                            STORE
                        </a>
                    </div>
                </div>
            </div>
            <div class="login">
                <div class="loginb">
                    <a href="login.php" id="login" style="color:white;">
                        LOGIN
                    </a>
                </div>
            </div>
        </div>

        <div class="video-container">
           <iframe width="560" height="315" src="https://www.youtube.com/embed/GSM0ert1vmI" frameborder="0" allowfullscreen></iframe>
        </div>
    </div>
    <div class="pokemon-container">
        <div class="pokemon-box">
            <img class="pokemon-image" src="https://wallpapers.com/images/featured/snorlax-t7wod9bjkjk3a3m2.jpg" alt="Pokemon Image">
                <div class="pokemon-description">
                    <h2>Snorlax</h2>
                    <p>Snorlax, known in Japan as Kabigon, is a Pokémon species, a type of Pocket Monster, in Nintendo and Game Freak's Pokémon franchise</p>
                </div>
            </div>

    <div class="pokemon-box">
        <img class="pokemon-image" src="https://assets.pokemon.com/assets/cms2/img/pokedex/full/150.png" alt="Pokemon Image">
            <div class="pokemon-description">
                    <h2>Mewtwo</h2>
                    <p>Mewtwo is an artificial Pokémon. It is a bipedal, humanoid Pokémon with some feline features. It is primarily gray with a long, purple tail. On top of its head are two short, blunt horns, and it has purple eyes. A tube extends from the back of its skull to the top of its spine, bypassing its neck</p>
                </div>
            </div>

    <div class="pokemon-box">
        <img class="pokemon-image" src="https://www.bitgab.com/uploads/1597796080-pikachu-1597796080.png" alt="Pokemon Image">
            <div class="pokemon-description">
                <h2>Pikachu</h2>
                <p>Pikachu is a short, chubby rodent Pokémon. It is covered in yellow fur with two horizontal brown stripes on its back. It has a small mouth, long, pointed ears with black tips, and brown eyes. Each cheek is a red circle that contains a pouch for electricity storage</p>
            </div>
        </div>
    </div>

    <div class="whole">
        <div class="footer">
            <div>
                <a href="https://facebook.com">FACEBOOK</a>
                <a href="https://twitter.com">TWITTER</a>
                <a href="https://instagram.com">INSTAGRAM</a>
            </div>
            <div>
                Contact: +1234567890
            </div>
            <div>
                &copy; <?php echo date("Y"); ?> Your Pokémon Website. All rights reserved.
            </div>
            <div>
                Pokémon is a trademark of The Pokémon Company.
            </div>
        </div>
    </div>
</body>
</html>