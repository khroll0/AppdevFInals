<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>Signup</title>
    <link rel="stylesheet" type="text/css" href="login.css">    

    <style>
        body#loginbody{
    background: url(https://free4kwallpapers.com/uploads/originals/2018/06/18/created-a-3d-render-of-a-pokemon-trophy-in-the-grass-wallpaper.jpg) no-repeat center center fixed;
    background-size: cover;
}

header{
    padding: absolute;
    top: 0;
    left: 0;
    width: 100%;
    padding: 30px 100px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    z-index: 10000;
}


header ul {
    list-style: none;
    margin-left: 20px;
}
header ul li a {
    text-decoration: none;
    padding: 6px 15px;
    color: #fff;
}

header ul li a:hover , 
header ul li a.active{
    background: #fff;
    color:#2b1055;
    border-radius: 20px;
}

.loginheader{
    text-align: center;
    margin-bottom: 60px;
}
.loginheader h1{
    font-size: 40px;
    color:blueviolet;
    padding: 0px;
    margin: 0px;

}
.loginheader p{
    color:black;
    font-size: 40px;
    border-bottom: 10px solid blanchedalmond transparent;
    margin: 0px;
    text-transform: uppercase;
    display: inline-block;
}
.loginheader p::after{
    content: " ";
    display: block;
    height: 5px;
    background: #f685a2;
    margin: 0 auto;
}

.loginbody form{
    /* margin-right: 50px; */
    height: 700px;
    width: 400px;
    background: rgba(0, 0, 0, .50);
    padding: 50px;
    /* border: 2px solid white; */
    border-radius: 20px;
}
.logininputcon{
    margin-top: 20px;
}

h2{
    margin-top: 20px;
    text-align: center;

}   

.logininputcon label{
    display: block;
    text-transform: uppercase;
    font-size: 20px;
    font-weight: bold;
    color: #fff;
}


.logininputcon input ::placeholder{
    margin-left: 20px;
    color:#fff;
}

.logininputcon input{
    height: 50px;
    width: 100%;
    border-radius: 5px;
    background: rgba(0, 0, 0, .5);
    border: 5px black;
}
.button{
    display:inline-flex;
    height: 50px;
    width:49%;
    padding: 0;
    background:#3b5998;
    border: none;
    outline: none;
    border-radius: 5px;
    overflow: hidden;
    font-family: 'quicksand', sans-serif;
    font-size: 16px;
    font-weight: 500;
    cursor: pointer;
}
.button:hover{
    background: #8b9dc3;
}
.button:active{
    background: #8b9dc3;
}

.button__icon{
   display: inline-flex;
   align-items: center;
   padding: 0 24px;
   color:#fff; 
   height: 100%;
}
.button__icon{
    align-items: center;
    font-size: 1.5em;
    /* background-color: rgba(0, 0, 0, 0.08); */
}
.log{
    display:inline-flex;
    height: 50px;
    width:100%;
    padding: 0;
    background:#7e0c04;
    border: none;
    outline: none;
    border-radius: 5px;
    overflow: hidden;
    font-family: 'quicksand', sans-serif;
    font-size: 16px;
    font-weight: 500;
    cursor: pointer;
}
.log:hover{
    background: #914141;
}
.log:active{
    background: #a0060694;
}

.log__Text{
    margin-left: 60px;
}   
.log__Text,
.log__iconn{
   display: inline-flex;
   align-items: center;
   padding: 0 25px;
   color:#fff; 
   height: 100%;

}
.log__iconn{
   
    font-size: 1.5em;
}

.error{
    /* background:##7e0c0400; */
    color: #fff;
    /* padding:10px; */
    height: 10px;
    width:95%;
    padding: 10px;
    border-radius: 5px;
    font-size: small;
}
.success{
    /* background:##7e0c0400; */
    color: #fff;
    /* padding:10px; */
    height: 10px;
    width:95%;
    padding: 10px;
    border-radius: 5px;
    font-size: small;
}

    </style>

</head>
<body id="loginbody">
        <div class="container">
        <div class="loginheader">
        </div>
        <div class="loginbody">
            <center>
            <form action="forsure.php" method="post">

            <img  style="width:180px" class="img-fluid" src="https://media2.giphy.com/media/jqcgAJzvWtMneZqKYd/200w.webp?cid=ecf05e47dqeyyddixtkg6fkgqn4n6zwedtyt0unt3fz6sd02&ep=v1_stickers_search&rid=200w.webp&ct=s"  >

                <?php if(isset($_GET['error'])){ ?>
                 <p class="error"><?php echo $_GET['error']; ?></p>
                    <?php }?>                
                    
                    <?php if(isset($_GET['success'])){ ?>
                 <p class="success"><?php echo $_GET['success']; ?></p>
                    <?php }?>
 
                    <?php if(isset($_GET['name'])){ ?>
                        <div class="logininputcon">
                        <input style="color:#fff"
                        type="text" 
                        name="name" 
                        placeholder="Name"   
                        value="<?php echo $_GET['name']; ?>">
                        </div>

                    <?php }else{?> 
                        <div class="logininputcon">
                        <input style="color:#fff"
                        type="text" 
                        name="name" 
                        placeholder="Name" >
                        </div>
                        <?php }?>
                       
                    <?php if(isset($_GET['uname'])){ ?>
                        <div class="logininputcon">
                        <input style="color:#fff"
                        type="text" 
                        name="uname" 
                        placeholder="Username" 
                        value="<?php echo $_GET['uname']; ?>">
                        </div>

                        <?php }else{?> 
                        <div class="logininputcon">    
                        <input style="color:#fff"
                        type="text" 
                        name="uname" 
                        placeholder="Username">
                        </div> 
                        <?php }?>

                <div class="logininputcon">
                <input type="password"  
                        name="pass" 
                        placeholder="Password"
                        style="color:#fff">
                </div>

                <div class="logininputcon">
                <input type="password"  
                        name="cpass" 
                        placeholder="Confirm password"
                        style="color:#fff">
                </div>

                <div style=" margin-top: 20px; ">
                <button href = "index.php" type="submit" class="log">
                        <span class="log__Text"> Signup</span>
                        <span class="log__iconn">
                        <ion-icon name="log-in-outline"></ion-icon>
                        </span>
                    </button>
                    <a class="already" href="index.php">Already have an account? </a>
                </div>
                
            </center>
            </form>

        </div>
    </div>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>

<script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>


</body>



</html>