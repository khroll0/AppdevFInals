<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="login.css">    

</head>
<body id="loginbody">
        <div class="container">
        <div class="loginheader">

        </div>
        <div class="loginbody">
            <center>
            <form action="login.php" method="post">

            <?php if(isset($_GET['error'])){ ?>
                 <p class="error"><?= $_GET['error']; ?></p>
                    <?php }?>

                 <img  style="width:180px" class="img-fluid" src="https://media3.giphy.com/media/Sd9XrDFZZ0Q0OXAdJM/200.webp?cid=ecf05e47dvydnsbbnpxgcjb14hk2o7ctaijgyqml6lg1is3u&ep=v1_stickers_search&rid=200.webp&ct=s"  >

                <div class="logininputcon">
                    <input type="text" name="uname" placeholder="Username"  style="color:#fff"/>
                </div>
                <div class="logininputcon">
                
                <input type="password"  name="pass" placeholder="Password" style="color:#fff" />
                    
                </div>
                <div style=" margin-top: 20px; ">
                
                <button type="submit" class="log">
                        <span class="log__Text"> Log In</span>
                        <span class="log__iconn">
                        <ion-icon name="log-in-outline"></ion-icon>
                        </span>
                    </button>
                    <a style="margin-right:160px"href="signup.php">Create an account</a>
                </div>

                <div>
                    <h2 style="color: #fff; font-size:15px; margin-top: 20px;">Connect With</h2>
                </div>
                <div>
                   
                <button type="button" class="button" onclick="window.open('https://www.facebook.com/login/', '_blank')">
                <span class="button__icon">
                <ion-icon name="logo-facebook"></ion-icon>
                </span>
                <span  class="button__text">Facebook</span>
                
            </button> 

            <button type="buttonn" class="buttonn" onclick="window.open('https://www.twitch.tv/login', '_blank')">
                <span class="buttonn__iconn">
                <ion-icon name="logo-twitch"></ion-icon>
                </span>
                <span class="button__textt">Twitch</span>
            </button>


                </div>
            </center>
            </form>

        </div>
    </div>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>

<script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>


</body>



</html>