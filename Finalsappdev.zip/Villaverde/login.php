<?php
session_start();

include "conn.php";

if(isset($_POST['uname']) && isset($_POST['pass'])){
    function validate($info){
    $infodata = trim($info);
        $info = stripcslashes($info);
        $info = htmlspecialchars($info);
        return $info;
    }
    $uname = validate($_POST['uname']);
    $passw = validate($_POST['pass']);

    if(empty($uname)){
        header("location: index.php?error=User Name is required");
        exit();
    }elseif(empty($passw)){
        header("location: index.php?error=Password is required");
        exit();
       
    }else{

        $passw = md5($passw);

        $dtbase = "SELECT * FROM users WHERE user_name='$uname' AND password='$passw'";

        $output = mysqli_query($conn, $dtbase);

        if(mysqli_num_rows($output) === 1 ){
            $acc = mysqli_fetch_assoc($output);
            if($acc['user_name'] === $uname && $acc['password'] === $passw){
                $_SESSION['user_name'] = $acc['user_name'];
                $_SESSION['name'] = $acc['name'];
                $_SESSION['id'] = $acc['id'];
                header("location: homepage.php");
                exit();
            }else{
                header("location: index.php?error=Incorrect Username");
                exit();
            }
            
        }else{
            header("location: index.php?error=Incorrect Username or pass");
            exit();
        }
    }

}else{
    header(("location: index.php"));
}

?>