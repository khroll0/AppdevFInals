<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Store</title>
</head>
<style>
    .body{
        padding-top: 190px;
        width: 70%;
        margin:auto;
    }
    .header{
        padding: 16px;
        background: #232423;
        position: fixed;
        top: 0;
        width: 100%;
        margin-left: -10px;
        z-index: 1;
    }
    body{
        background: #1b1c1c;
    }
    #logo{
        width: 230px;
        height: 143.75px;
        margin-left: 350px;
        padding: 10px;
    }
    .logo,.login{
        float: left;
    }
    .logo{
        width: 75%;
    }
    .login{
        width: 25%;
        margin-top: 40px;
        font-size: 35px;
    }
    .log{
        border-radius: 50px;
        border: 1px solid;
        background: green;
        border-color: olive;
        padding: 5px;
        padding-left: 25px;
        width: 160px;
    }
    a:link {
        text-decoration: none;
        color: white;
    }

    a:visited {
        text-decoration: none;
    }

    a:active {
        text-decoration: underline;
    }
    .loginb{
        color: white;
        padding: 10px;
    }
    .footer {
            background: #163973;
            color: white;
            padding: 30px;
            text-align: center;
            bottom: 0;
            width: 100%;
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-top: 100px;
        }
        
        .footer a {
            color: white;
            text-decoration: wordwrap;
            margin: 5px;
            font-size: 17px;
        }
        
        .footer div {
            margin-bottom: 10px;
        }
    .bundle{
        float: left;
    }
    .quantity{
        float: right;
        margin-top: 60px;
        margin-right: 200px;
    }
    .b1:after{
        content: "";
        display: table;
        clear: both;
    }
    input{
        width: 15   0px;
        height: 30px;
    }
    .submit{
        margin-left: 40%;
    }
    input[type="submit"] {
            margin-top: 30px;
            width: 170px;
            height: 50px;
            font-size: 20px;   
            border-radius: 50px; 
            background-image: linear-gradient(to right, #80c4a1, #409c83);
    }
</style>
<body>
    <?php session_start(); ?>
    <div class = "header">
        <div class = "logo">
            <a href = "homepage.php"><img id = "logo" src = "https://lh3.googleusercontent.com/3TSaKxXGo2wT0lu0AyNUBnkk6wkCC2AzOhJyy3JXIPm-AmZ1k9DSAroWeBUyePswCZSs5lVp3mPF7HzUpY9VPlyOV5eddITONINr3WSqLNLm=e365-w512"></a>
        </div>
        <div class = "login">
            <div class ="loginb">
                <div class = "log">
                    <a href= "login.php" id = login style = color:white;>
                        SIGN-UP
                    </a>
                </div>
            </div>
        </div>
    </div> 
<div class = "body">
<form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
    <div class = "b1">
        <div class = "bundle">
            <div class = "picture">
                <img id = "pic1" src = "https://store.pokemongolive.com/_next/image?url=https%3A%2F%2Fcdn3.xsolla.com%2Fimg%2Fmisc%2Fimages%2F070822898eca123f2f2dd9f1759f9734.png&w=128&q=75">
            </div>
            <div class = "text">600 PokéCoins</div>
        </div>
        <div class = "quantity">
            <input type = "number" name = "qty1" id = "qty1" min = "0" max = "99"></input>
        </div>
    </div> 
    <div class = "b1">
        <div class = "bundle">
            <div class = "picture">
                <img id = "pic1" src = "https://store.pokemongolive.com/_next/image?url=https%3A%2F%2Fcdn3.xsolla.com%2Fimg%2Fmisc%2Fimages%2F28042bf667a908f5761e677f1cb62f1f.png&w=128&q=75">
            </div>
            <div class = "text">600 PokéCoins</div>
        </div>
        <div class = "quantity">
            <input type = "number" name = "qty2" id = "qty2" min = "0" max = "99"></input>
        </div>
    </div>
    <div class = "b1">
        <div class = "bundle">
            <div class = "picture">
                <img id = "pic1" src = "https://store.pokemongolive.com/_next/image?url=https%3A%2F%2Fcdn3.xsolla.com%2Fimg%2Fmisc%2Fimages%2Fdb583406b118ae8d86b525add9a4132d.png&w=128&q=75">
            </div>
            <div class = "text">600 PokéCoins</div>
        </div>
        <div class = "quantity">
            <input type = "number" name = "qty3" id = "qty3" min = "0" max = "99"></input>
        </div>
    </div>
    <div class = "b1">
        <div class = "bundle">
            <div class = "picture">
                <img id = "pic1" src = "https://store.pokemongolive.com/_next/image?url=https%3A%2F%2Fcdn3.xsolla.com%2Fimg%2Fmisc%2Fimages%2F7ca5a8f30cbcf9ab08548b391a425e06.png&w=128&q=75">
            </div>
            <div class = "text">600 PokéCoins</div>
        </div>
        <div class = "quantity">
            <input type = "number" name = "qty4" id = "qty4" min = "0" max = "99"></input>
        </div>
    </div> 
    <div class = "b1">
        <div class = "bundle">
            <div class = "picture">
                <img id = "pic1" src = "https://store.pokemongolive.com/_next/image?url=https%3A%2F%2Fcdn3.xsolla.com%2Fimg%2Fmisc%2Fimages%2F8cabb613cc3703e052629e0bc7eec1af.png&w=128&q=75">
            </div>
            <div class = "text">600 PokéCoins</div>
        </div>
        <div class = "quantity">
            <input type = "number" name = "qty5" id = "qty5" min = "0" max = "99"></input>
        </div>
    </div> 
    <div class = "submit">
        <input type="submit" value="Check Out"></input>
    </div>  
</div>
<?php
    include "conn.php";
    $sql = "SELECT user_name, id FROM users";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
        if ($_SESSION["user_name"] == $row["user_name"]) {
        $id = $row["id"];
    }
    $quantity = 0;
}
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $q1 = $_POST["qty1"];
        $q2 = $_POST["qty2"];
        $q3 = $_POST["qty3"];
        $q4 = $_POST["qty4"];
        $q5 = $_POST["qty5"];

        if($q1 > 0)
        {
            $product = "Bundle 1";
            $quantity = $q1;
      }
      elseif($q2>0){
        $product = "Bundle 2";
            $quantity = $q2;
      }
      elseif($q3>0){
        $product = "Bundle 3";
            $quantity = $q3;
      }
      elseif($q4>0){
        $product = "Bundle 4";
            $quantity = $q4;
      }
      elseif($q5>0){
        $product = "Bundle 5";
        $quantity = $q5;
      }
    }
            $dtbase2 = "INSERT INTO order(product, quantity, id) VALUES ('$product', '$quantity', '$id')";
            $output2 = mysqli_query($conn, $dtbase2);
    }
    ?>
<div class="footer">
            <div>
                <a href="https://facebook.com">FACEBOOK</a>
                <a href="https://twitter.com">TWITTER</a>
                <a href="https://instagram.com">INSTAGRAM</a>
            </div>
            <div>
                Contact: +1234567890
            </div>
            <div>
                &copy; <?php echo date("Y"); ?> Your Pokémon Website. All rights reserved.
            </div>
            <div>
                Pokémon is a trademark of The Pokémon Company.
            </div>
        </div>
</body>
</html>