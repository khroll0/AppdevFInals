<?php
session_start();

include "conn.php";

    if(isset($_POST['uname']) && isset($_POST['pass']) 
    && isset($_POST['name']) && isset($_POST['cpass'])){
    function validate($info){
    $info = trim($info);
        $info = stripcslashes($info);
        $info = htmlspecialchars($info);
        return $info;
    }

    $uname = validate($_POST['uname']);
    $passw = validate($_POST['pass']);
    $cpass = validate($_POST['cpass']);
    $name = validate($_POST['name']);

    $datagot = 'uname=' . $uname . '&name='. $name;


    if(empty($uname)){
        header("location: signup.php?error= You need to put a Username&$datagot");
        exit();
    }elseif(empty($passw)){
        header("location: signup.php?error= You need to put a  password&$datagot");
        exit();
       
    }elseif(empty($cpass)){
        header("location: signup.php?error= Confirm Password is required&$datagot");
        exit();
    }elseif(empty($name)){
        header("location: signup.php?error= You need to put a Name&$datagot");
        exit();
    }else if($passw !== $cpass){
        header("Location: signup.php?error=Password didnt match&$datagot");
	    exit();
	}
    
    else{

        $passw = md5($passw);

        $dtbase = "SELECT * FROM users WHERE user_name='$uname' ";
        $output = mysqli_query($conn, $dtbase);

         if(mysqli_num_rows($output) > 0 ){
            header("location: signup.php?error= The username is already taken!&$datagot");
            exit();
        }else{
            $dtbase2 = "INSERT INTO users(user_name, password, name) VALUES ('$uname', '$passw', '$name')";
            $output2 = mysqli_query($conn, $dtbase2);
            if($output2){
                header("location: signup.php?success=Account Created&$datagot");
                exit();
            }else{
                header("location: signup.php?error=error 404&$datagot");
                exit();
            }
        }

    }

}else{
    header(("location: signup.php"));
     exit();
}

?>