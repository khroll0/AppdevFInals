<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Store</title>
</head>
<style>
    .body{
        padding-top: 190px;
        width: 70%;
        margin:auto;
    }
    .header{
        padding: 16px;
        background: #232423;
        position: fixed;
        top: 0;
        width: 100%;
        margin-left: -10px;
        z-index: 1;
    }
    body{
        background: #1b1c1c;
    }
    #logo{
        width: 230px;
        height: 143.75px;
        margin-left: 350px;
        padding: 10px;
    }
    .logo,.login{
        float: left;
    }
    .logo{
        width: 75%;
    }
    .login{
        width: 25%;
        margin-top: 40px;
        font-size: 35px;
    }
    .log{
        border-radius: 50px;
        border: 1px solid;
        background: green;
        border-color: olive;
        padding: 5px;
        padding-left: 25px;
        width: 160px;
    }
    a:link {
        text-decoration: none;
        color: white;
    }

    a:visited {
        text-decoration: none;
    }

    a:active {
        text-decoration: underline;
    }
    .loginb{
        color: white;
        padding: 10px;
    }
    #pokemon{
        width: 100%;
        border-radius: 30px;
    }
    .Ptext{
        position: absolute;
        bottom: 230px;
        color:white;
        right: 400px;
        font-size: 80px;
    }
    .store{
        color: #5ebdbd;
        font-size: 50px;
        margin-top: 100px;
    }
    #applogo{
        width: 300px;
        padding: 70px;
        margin-left: 20px;
    }
    .desc{
        color: white;
        font-size: 30px;
    }
    .applogo{
        width: 30%;
        float: left;
    }
    .app{
        background-image: linear-gradient(to right, #113f57 , #2685b5);
        border-radius: 30px;
        width: 70%;   
        margin: auto;
    }
    .desc{
        width: 70%;
        float: left;
        text-align: center;
    }
    .app:after{
        content: "";
        display: table;
        clear: both;
    }
    .apple, .gplay, .galaxy{
        width: 33.33%;
        float: left;
    }
    .d1:after{
        content: "";
        display: table;
        clear: both;
    }
    #apple, #gplay, #galaxy{
        width: 180px;
    }
    .desct{
        font-size: 60px;
        padding: 70px;
        padding-bottom: 20px;
    }
    .bundles{
        margin-left: 190px;
        margin-bottom: 200px;
    }
    .bundles:after{
        content: "";
        display: table;
        clear: both;
    }
    .bundle1{
        width: 400px;
        float: left;
        border-radius: 30px;
        padding: 10px;
    }
    .bundle1:hover{
        box-shadow: 0px 0px 10px 3px #696868;
    }
    .title{
        background: #455953;
        height: 150px;
        padding: 50px;
        border-top-left-radius: 30px;
        border-top-right-radius: 30px;
    }
    .content{
        color: white;
        font-size: 30px;
        padding: 30px;
    }
    #bundle1{
        margin-left: 90px;
    }
    input[type="submit"] {
            margin-top: 30px;
            margin-left: 85 px;
            width: 170px;
            height: 50px;
            font-size: 20px;   
            border-radius: 50px; 
            background-image: linear-gradient(to right, #80c4a1, #409c83);
    }
    .price{
        font-size: 25px;
    }
    .footer {
            background: #163973;
            color: white;
            padding: 30px;
            text-align: center;
            bottom: 0;
            width: 100%;
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-top: 100px;
        }
        
        .footer a {
            color: white;
            text-decoration: wordwrap;
            margin: 5px;
            font-size: 17px;
        }
        
        .footer div {
            margin-bottom: 10px;
        }
</style>
<body>
    <div class = "header">
        <div class = "logo">
            <a href = "homepage.php"><img id = "logo" src = "https://lh3.googleusercontent.com/3TSaKxXGo2wT0lu0AyNUBnkk6wkCC2AzOhJyy3JXIPm-AmZ1k9DSAroWeBUyePswCZSs5lVp3mPF7HzUpY9VPlyOV5eddITONINr3WSqLNLm=e365-w512"></a>
        </div>
        <div class = "login">
            <div class ="loginb">
                <div class = "log">
                    <a href= "login.php" id = login style = color:white;>
                        SIGN-UP
                    </a>
                </div>
            </div>
        </div>
    </div> 
<div class = "body">
<div class = "picture">
    <img src = "https://dotesports.com/wp-content/uploads/2021/02/14203950/ESYYGevWAAII0ma.jpg" id = "pokemon">
    <div class = "Ptext">
    Welcome to the PokéStore!!!<br>
    Buy PokéCoins now and get<br>
     Exclusive Freebies.
    </div>
</div>
<div class = "store">
    <b>PokéCoins</b><br><br>
    <div class = "bundles">
        <div class = "bundle1">
            <div class = "title">
                <img id = "bundle1" src = "https://store.pokemongolive.com/_next/image?url=https%3A%2F%2Fcdn3.xsolla.com%2Fimg%2Fmisc%2Fimages%2F070822898eca123f2f2dd9f1759f9734.png&w=128&q=75">
            </div>
            <div class = "content">
                600 PokéCoins<br>
                <div class = "bonus">
                    50 PokéStore Bonus Coins
                </div>
                <br><br><div class = "price">₱249.00</div>
                <form method="POST" action="/Villaverde/checkout.php">
                <input type="submit" value="Buy"></input>
                </form>
            </div>
        </div>
        <div class = "bundle1">
            <div class = "title">
                <img id = "bundle1" src = "https://store.pokemongolive.com/_next/image?url=https%3A%2F%2Fcdn3.xsolla.com%2Fimg%2Fmisc%2Fimages%2F070822898eca123f2f2dd9f1759f9734.png&w=128&q=75">
            </div>
            <div class = "content">
                600 PokéCoins<br>
                <div class = "bonus">
                    50 PokéStore Bonus Coins
                </div>
                <br><br><div class = "price">₱249.00</div>
                <form method="POST" action="/Villaverde/checkout.php">
                <input type="submit" value="Buy"></input>
                </form>
            </div>
        </div>
        <div class = "bundle1">
            <div class = "title">
                <img id = "bundle1" src = "https://store.pokemongolive.com/_next/image?url=https%3A%2F%2Fcdn3.xsolla.com%2Fimg%2Fmisc%2Fimages%2F070822898eca123f2f2dd9f1759f9734.png&w=128&q=75">
            </div>
            <div class = "content">
                600 PokéCoins<br>
                <div class = "bonus">
                    50 PokéStore Bonus Coins
                </div>
                <br><br><div class = "price">₱249.00</div>
                <form method="POST" action="/Villaverde/checkout.php">
                <input type="submit" value="Buy"></input>
                </form>
            </div>
        </div>
        <div class = "bundle1">
            <div class = "title">
                <img id = "bundle1" src = "https://store.pokemongolive.com/_next/image?url=https%3A%2F%2Fcdn3.xsolla.com%2Fimg%2Fmisc%2Fimages%2F070822898eca123f2f2dd9f1759f9734.png&w=128&q=75">
            </div>
            <div class = "content">
                600 PokéCoins<br>
                <div class = "bonus">
                    50 PokéStore Bonus Coins
                </div>
                <br><br><div class = "price">₱249.00</div>
                <form method="POST" action="/Villaverde/checkout.php">
                <input type="submit" value="Buy"></input>
                </form>
            </div>
        </div>
        <div class = "bundle1">
            <div class = "title">
                <img id = "bundle1" src = "https://store.pokemongolive.com/_next/image?url=https%3A%2F%2Fcdn3.xsolla.com%2Fimg%2Fmisc%2Fimages%2F070822898eca123f2f2dd9f1759f9734.png&w=128&q=75">
            </div>
            <div class = "content">
                600 PokéCoins<br>
                <div class = "bonus">
                    50 PokéStore Bonus Coins
                </div>
                <br><br><div class = "price">₱249.00</div>
                <form method="POST" action="/Villaverde/checkout.php">
                <input type="submit" value="Buy"></input>
                </form>
            </div>
        </div>
    </div>
    <div class = "app">
        <div class = "applogo">
            <img src = "https://store.pokemongolive.com/_next/image?url=%2F_next%2Fstatic%2Fmedia%2Fpgo-logo-white-outline.d3f679a8.png&w=3840&q=75" id = "applogo">
        </div>
        <div class = "desc">
            <div class = "desct">Get up and GO! <br>Download Today</div>
            <div class = "dl">
                <div class = "apple">
                    <a href = "https://apps.apple.com/vc/app/pok%C3%A9mon-go/id1094591345">
                    <img id = "apple" src = "https://store.pokemongolive.com/_next/static/media/Apple_Badge_EN.a2e763b8.svg">
                    </a>
                </div>
                <div class = "gplay">
                    <a href = "https://play.google.com/store/apps/details?id=com.nianticlabs.pokemongo&pli=1">
                    <img id = "gplay" src = "https://store.pokemongolive.com/_next/image?url=%2F_next%2Fstatic%2Fmedia%2Fgoogle-play-badge_en.333e8411.png&w=640&q=75">
                    </a>
                </div>
                <div class = "galaxy">
                <a href = "https://galaxystore.samsung.com/detail/com.nianticlabs.pokemongo.ares">
                    <img id = "galaxy" src = "https://store.pokemongolive.com/_next/image?url=%2F_next%2Fstatic%2Fmedia%2FGalaxyStore_English.2ff46298.png&w=750&q=75">
                </a>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<div class="whole">
        <div class="footer">
            <div>
                <a href="https://facebook.com">FACEBOOK</a>
                <a href="https://twitter.com">TWITTER</a>
                <a href="https://instagram.com">INSTAGRAM</a>
            </div>
            <div>
                Contact: +1234567890
            </div>
            <div>
                &copy; <?php echo date("Y"); ?> Your Pokémon Website. All rights reserved.
            </div>
            <div>
                Pokémon is a trademark of The Pokémon Company.
            </div>
        </div>
    </div> 
</body>
</html>